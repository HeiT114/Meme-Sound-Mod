package com.example.musicplayermod.client;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

/**
 * 循环播放的音乐声音实例。
 * 由外部控制生命周期：start 后循环播放，调用 {@link #stop()} 立即停止。
 */
public class PlayerMusicSoundInstance extends AbstractTickableSoundInstance {

	public PlayerMusicSoundInstance(SoundEvent soundEvent, SoundSource source) {
		super(soundEvent, source, SoundInstance.createUnseededRandom());
		this.volume = 1.0F;
		this.pitch = 1.0F;
		this.looping = true;      // 循环播放，直到 stop()
		this.relative = true;     // 相对于玩家，不受距离衰减
		this.attenuation = SoundInstance.Attenuation.NONE;
	}

	@Override
	public void tick() {
		// 无需逐刻更新，由调用方通过 stop() 控制结束
	}

	@Override
	public boolean canStartSilent() {
		return true;
	}
}
