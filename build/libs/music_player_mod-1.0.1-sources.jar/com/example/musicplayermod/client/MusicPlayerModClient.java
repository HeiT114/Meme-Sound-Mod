package com.example.musicplayermod.client;

import com.example.musicplayermod.MusicPlayerMod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

/**
 * 客户端入口：每个游戏刻检测玩家状态。
 * <ul>
 *   <li>开始飞行（创造飞行/鞘翅）→ 循环播放《中国人能飞》；停止飞行 → 立即停止</li>
 *   <li>死亡 → 循环播放《See You Again》；点确认重生 → 立即停止</li>
 * </ul>
 */
public class MusicPlayerModClient implements ClientModInitializer {

	/** 上一刻的飞行状态 */
	private boolean wasFlying = false;

	/** 上一刻的死亡状态 */
	private boolean wasDead = false;

	/** 当前正在循环播放的飞行音乐实例 */
	private PlayerMusicSoundInstance flyMusic;

	/** 当前正在循环播放的死亡音乐实例 */
	private PlayerMusicSoundInstance deathMusic;

	@Override
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			LocalPlayer player = client.player;
			if (player == null) {
				// 未进入世界 / 断线：停止所有音乐并重置状态
				stopMusic(flyMusic);
				stopMusic(deathMusic);
				flyMusic = null;
				deathMusic = null;
				wasFlying = false;
				wasDead = false;
				return;
			}

			boolean dead = player.isDeadOrDying();

			if (dead) {
				// —— 死亡状态：停止飞行音乐，循环播放死亡音乐 ——
				if (!wasDead) {
					stopMusic(flyMusic);
					flyMusic = null;
					deathMusic = startMusic(MusicPlayerMod.DEATH_SOUND.event());
					MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player died, playing see_you_again (loop)");
				}
			} else {
				// —— 飞行检测（创造模式飞行 或 鞘翅滑翔） ——
				boolean flying = player.getAbilities().flying || player.isFallFlying();
				if (flying && !wasFlying) {
					flyMusic = startMusic(MusicPlayerMod.FLY_SOUND.event());
					MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player started flying, playing chinese_can_fly (loop)");
				} else if (!flying && wasFlying) {
					stopMusic(flyMusic);
					flyMusic = null;
					MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player stopped flying, stopping music");
				}
				wasFlying = flying;

				// —— 重生检测：点确认死亡并重生后立即停止死亡音乐 ——
				if (wasDead) {
					stopMusic(deathMusic);
					deathMusic = null;
					wasFlying = false; // 允许重生后仍处于飞行状态时重新触发
					MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player respawned, stopping music");
				}
			}

			wasDead = dead;
		});
	}

	/** 开始循环播放一段音乐 */
	private PlayerMusicSoundInstance startMusic(SoundEvent soundEvent) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft == null || minecraft.getSoundManager() == null) {
			return null;
		}
		PlayerMusicSoundInstance instance = new PlayerMusicSoundInstance(soundEvent, SoundSource.MASTER);
		minecraft.getSoundManager().play(instance);
		return instance;
	}

	/** 立即停止正在播放的音乐 */
	private void stopMusic(PlayerMusicSoundInstance instance) {
		if (instance != null) {
			Minecraft minecraft = Minecraft.getInstance();
			if (minecraft != null && minecraft.getSoundManager() != null) {
				minecraft.getSoundManager().stop(instance);
			}
		}
	}
}
