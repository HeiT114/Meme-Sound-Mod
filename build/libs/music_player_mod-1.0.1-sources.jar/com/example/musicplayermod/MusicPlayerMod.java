package com.example.musicplayermod;

import net.fabricmc.api.ModInitializer;

import net.minecraft.resources.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 模组主入口。
 * 在服务端/客户端通用环境中注册自定义声音事件。
 */
public class MusicPlayerMod implements ModInitializer {
	public static final String MOD_ID = "music_player_mod";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** 飞行时播放的声音（中国人能飞） */
	public static final ModSound FLY_SOUND = ModSound.registerSound("chinese_can_fly");

	/** 死亡时播放的声音（See You Again） */
	public static final ModSound DEATH_SOUND = ModSound.registerSound("see_you_again");

	@Override
	public void onInitialize() {
		// 静态字段初始化即完成声音注册，这里仅输出日志
		LOGGER.info("[MusicPlayerMod] initialized, {} sounds registered", 2);
	}

	/** 便捷方法：生成属于本模组的 Identifier */
	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
