package com.example.musicplayermod.client;

import com.example.musicplayermod.MusicPlayerMod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;

/**
 * 客户端入口：每个游戏刻检测玩家状态，
 * 开始飞行时播放「中国人能飞」，死亡时播放「See You Again」。
 */
public class MusicPlayerModClient implements ClientModInitializer {

	/** 上一刻的飞行状态，用于捕捉“开始飞行”的上升沿 */
	private boolean wasFlying = false;

	/** 上一刻的死亡状态，用于捕捉“死亡”的上升沿 */
	private boolean wasDead = false;

	@Override
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			LocalPlayer player = client.player;
			if (player == null) {
				// 未进入世界 / 断线时重置状态，避免重新进入后漏触发
				wasFlying = false;
				wasDead = false;
				return;
			}

			// —— 飞行检测（创造模式飞行 或 鞘翅滑翔） ——
			boolean flying = player.getAbilities().flying || player.isFallFlying();
			if (flying && !wasFlying) {
				playSound(MusicPlayerMod.FLY_SOUND.event());
				MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player started flying, playing chinese_can_fly");
			}
			wasFlying = flying;

			// —— 死亡检测 ——
			boolean dead = player.isDeadOrDying();
			if (dead && !wasDead) {
				playSound(MusicPlayerMod.DEATH_SOUND.event());
				MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player died, playing see_you_again");
			}
			wasDead = dead;
		});
	}

	/**
	 * 在本地客户端播放一次声音（只影响本机，不广播给其他玩家）。
	 */
	private void playSound(SoundEvent soundEvent) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft != null && minecraft.getSoundManager() != null) {
			minecraft.getSoundManager().play(SimpleSoundInstance.forUI(soundEvent, 1.0F));
		}
	}
}
