package com.example.musicplayermod.client;

import com.example.musicplayermod.ModConfig;
import com.example.musicplayermod.MusicPlayerMod;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * 模组设置界面（默认按 K 键打开）：
 * <ul>
 *   <li>音量滑条（0% ~ 100%，作用于所有音效）</li>
 *   <li>模组版本号显示</li>
 *   <li>按键说明</li>
 * </ul>
 * 点「Save & Close」保存配置并关闭。
 */
public class SettingsScreen extends Screen {

	private VolumeSlider volumeSlider;

	public SettingsScreen() {
		super(Component.literal("Music Player Mod Settings"));
	}

	@Override
	protected void init() {
		int cx = this.width / 2;

		// 音量滑条
		this.volumeSlider = new VolumeSlider(cx - 100, 60, 200, 20, ModConfig.get().volume);
		this.addRenderableWidget(this.volumeSlider);

		// 保存并关闭
		this.addRenderableWidget(Button.builder(Component.literal("Save & Close"), button -> {
			ModConfig.get().volume = this.volumeSlider.getVolume();
			ModConfig.save();
			this.onClose();
		}).bounds(cx - 100, 100, 200, 20).build());

		// 重置为 100%
		this.addRenderableWidget(Button.builder(Component.literal("Reset to 100%"), button -> {
			this.volumeSlider.setVolumeValue(1.0D);
		}).bounds(cx - 100, 130, 200, 20).build());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		int cx = this.width / 2;

		graphics.text(this.font, "Volume: " + Math.round(this.volumeSlider.getVolume() * 100) + "%", cx - 100, 40, 0xFFFFFFFF, true);
		graphics.text(this.font, "Mod Version: " + MusicPlayerMod.getVersion(), cx - 100, 170, 0xFFFFFFFF, true);
		graphics.text(this.font, "C: Vine Boom | K: Settings", cx - 100, 190, 0xFFFFFFFF, true);
	}

	@Override
	public void onClose() {
		if (this.minecraft != null) {
			this.minecraft.setScreen(null);
		}
	}

	/** 音量滑条：0.0 ~ 1.0 */
	private static class VolumeSlider extends AbstractSliderButton {

		VolumeSlider(int x, int y, int width, int height, double value) {
			super(x, y, width, height, Component.empty(), clamp(value));
		}

		float getVolume() {
			return (float) this.value;
		}

		void setVolumeValue(double value) {
			this.value = clamp(value);
			this.updateMessage();
		}

		@Override
		protected void updateMessage() {
			this.setMessage(Component.literal(Math.round(this.value * 100) + "%"));
		}

		@Override
		protected void applyValue() {
			// 值在保存时才写入配置
		}

		private static double clamp(double value) {
			return Math.max(0.0D, Math.min(1.0D, value));
		}
	}
}
