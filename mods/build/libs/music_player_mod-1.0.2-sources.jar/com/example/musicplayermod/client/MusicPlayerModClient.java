package com.example.musicplayermod.client;

import com.example.musicplayermod.ModConfig;
import com.example.musicplayermod.MusicPlayerMod;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import org.lwjgl.glfw.GLFW;

/**
 * 客户端入口：
 * <ul>
 *   <li>开始飞行（创造/鞘翅）→ 循环播放《中国人能飞》；停止飞行 → 立即停止</li>
 *   <li>死亡 → 循环播放《See You Again》；点重生 → 立即停止</li>
 *   <li>按 C 键 → 播放 vine boom</li>
 *   <li>按 K 键 → 打开模组设置界面</li>
 * </ul>
 * 所有音效音量受模组设置（config/music_player_mod.json）控制。
 */
public class MusicPlayerModClient implements ClientModInitializer {

	/** C 键：播放 vine boom */
	private static final KeyMapping VINE_BOOM_KEY = new KeyMapping(
			"key.music_player_mod.vine_boom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, KeyMapping.Category.MISC);

	/** K 键：打开设置界面 */
	private static final KeyMapping SETTINGS_KEY = new KeyMapping(
			"key.music_player_mod.settings", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, KeyMapping.Category.MISC);

	/** 上一刻的飞行状态 */
	private boolean wasFlying = false;

	/** 上一刻的死亡状态 */
	private boolean wasDead = false;

	/** 当前正在循环播放的飞行音乐实例 */
	private PlayerMusicSoundInstance flyMusic;

	/** 当前正在循环播放的死亡音乐实例 */
	private PlayerMusicSoundInstance deathMusic;

	@Override
	public void onInitializeClient() {
		ModConfig.load();
		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
	}

	private void onTick(Minecraft client) {
		// —— 打开设置界面（默认 K 键） ——
		while (SETTINGS_KEY.consumeClick()) {
			if (client.screen == null) {
				client.setScreen(new SettingsScreen());
				MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Opened settings screen");
			}
		}

		// —— C 键播放 vine boom ——
		while (VINE_BOOM_KEY.consumeClick()) {
			playOneShot(MusicPlayerMod.VINE_BOOM_SOUND.event());
			MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Played vine boom (key C)");
		}

		LocalPlayer player = client.player;
		if (player == null) {
			// 未进入世界 / 断线：停止所有音乐并重置状态
			stopMusic(flyMusic);
			stopMusic(deathMusic);
			flyMusic = null;
			deathMusic = null;
			wasFlying = false;
			wasDead = false;
			return;
		}

		boolean dead = player.isDeadOrDying();

		if (dead) {
			// —— 死亡状态：停止飞行音乐，循环播放死亡音乐 ——
			if (!wasDead) {
				stopMusic(flyMusic);
				flyMusic = null;
				deathMusic = startMusic(MusicPlayerMod.DEATH_SOUND.event());
				MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player died, playing see_you_again (loop)");
			}
		} else {
			// —— 飞行检测（创造模式飞行 或 鞘翅滑翔） ——
			boolean flying = player.getAbilities().flying || player.isFallFlying();
			if (flying && !wasFlying) {
				flyMusic = startMusic(MusicPlayerMod.FLY_SOUND.event());
				MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player started flying, playing chinese_can_fly (loop)");
			} else if (!flying && wasFlying) {
				stopMusic(flyMusic);
				flyMusic = null;
				MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player stopped flying, stopping music");
			}
			wasFlying = flying;

			// —— 重生检测：点确认死亡并重生后立即停止死亡音乐 ——
			if (wasDead) {
				stopMusic(deathMusic);
				deathMusic = null;
				wasFlying = false; // 允许重生后仍处于飞行状态时重新触发
				MusicPlayerMod.LOGGER.info("[MusicPlayerMod] Player respawned, stopping music");
			}
		}

		wasDead = dead;
	}

	/** 开始循环播放一段音乐（音量取模组设置） */
	private PlayerMusicSoundInstance startMusic(SoundEvent soundEvent) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft == null || minecraft.getSoundManager() == null) {
			return null;
		}
		PlayerMusicSoundInstance instance = new PlayerMusicSoundInstance(soundEvent, SoundSource.MASTER, ModConfig.get().volume);
		minecraft.getSoundManager().play(instance);
		return instance;
	}

	/** 立即停止正在播放的音乐 */
	private void stopMusic(PlayerMusicSoundInstance instance) {
		if (instance != null) {
			Minecraft minecraft = Minecraft.getInstance();
			if (minecraft != null && minecraft.getSoundManager() != null) {
				minecraft.getSoundManager().stop(instance);
			}
		}
	}

	/** 播放一次音效（man / vine boom，不循环，音量取模组设置） */
	private void playOneShot(SoundEvent soundEvent) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft != null && minecraft.getSoundManager() != null) {
			minecraft.getSoundManager().play(SimpleSoundInstance.forUI(soundEvent, ModConfig.get().volume, 1.0F));
		}
	}
}
